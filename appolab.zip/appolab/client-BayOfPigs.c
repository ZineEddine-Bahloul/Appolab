#include "client.h"

#include <stdio.h>

#include <ctype.h>

#include <stdbool.h>

#include <string.h>


#define MAXMSG MAXREP


void vider_str(char *str){
    int len1 = strlen(str);
    for (int i = 0; i < len1; i++)
    {
        str[i] = '\0';
    }
}

void deplacer(char *txt,int n){
    int i=0;
    int len = strlen(txt);
    char s1[len];
    vider_str(s1);
    char s2[len];
    vider_str(s2);
    if (n >= 0)
    {
        while (i<len){
            if (i<n){
                s1[i]=txt[i];
            }
            else {
                s2[i - n] = txt[i];
            }
            i=i+1;
        }
        s1[n] = '\0';
        s2[len - n] = '\0';
        strcat(s2, s1);
        s2[len] = '\0';
        vider_str(txt);
        strcpy(txt, s2);
        vider_str(s1);
        vider_str(s2);
    }
}

void del_first_let (char *txt){
    int len1 = strlen(txt);
    if (len1 > 0)
    {
        int i = 1;
        char s1_1[len1];
        vider_str(s1_1);
        while (i<len1){
            s1_1[i-1]=txt[i];
            i=i+1;
        }
        s1_1[len1 -1]='\0';
        vider_str(txt);
        strcpy(txt, s1_1);
        vider_str(s1_1);
        // printf("\n");
    }
}

void encrypter(char *txt,char *enc){
    vider_str(enc);
    char c[2];
    vider_str(c);
    unsigned long x;
    int i = 0;
    while (txt[0] != '\0' ){
        c[0] = txt [0];
        c[1] = '\0';
        // printf("txt 1 :|%c|\n", txt[0]);
        // printf("enc:%s\n",enc);
        strcat(enc, c);
        //printf("test:|%c|\n",c[0]);
        del_first_let(txt);
        x=c[0] %8 ;
        //printf("x:%d\n",x);
        if (strlen(txt) >= x && x>=1){
            //printf("txt 2 :%s\n",txt);
            deplacer(txt,x);
            //printf("\ntxt 3 :%s\n",txt);
        }
        vider_str(c);
        i++;
    }
}


void inserer_premier_char (char *txt,char c){
    int len3 = strlen(txt);
    char txt_inter2[MAXREP];
    vider_str(txt_inter2);
    for (int idx2 = 0; idx2 < len3 + 1; idx2++)
    {
        if (idx2 == 0){
            txt_inter2[idx2] = c;
        }
        else {
            txt_inter2[idx2] = txt[idx2-1] ;
            txt_inter2[idx2 + 1] = '\0';
        }
    }
    vider_str(txt);
    strcpy(txt,txt_inter2);
    vider_str(txt_inter2);
}

void decaler_xderniers(char *txt, int x){
    char c2;
    int len2 = strlen(txt);
    char txt_inter[MAXREP];
    vider_str(txt_inter);
    int dernier_idx = len2 - 1;
    if (x <= len2 && x>=1)
    {
        for (int idx1 = 0; idx1 < x; idx1++){
            c2 = txt[dernier_idx - idx1 ];
            txt[dernier_idx - idx1] = '\0';
            inserer_premier_char(txt_inter, c2);
        }
        strcat(txt_inter, txt);
        vider_str(txt);
        strcpy(txt,txt_inter);
        vider_str(txt_inter);
    }
}
void decrypter(char *enc,char *txt){
    char c;
    int x;
    vider_str(txt);
    while (enc[0] != '\0')
    {
        int len4 = strlen(enc);
        c = enc[len4 - 1];
        x = c % 8;
        decaler_xderniers(txt, x);
        inserer_premier_char(txt, c);
        enc[len4 - 1] = '\0';
    }
}

int main() {

    char reponse[MAXREP]; // pour stocker la réponse du serveur

    char result[MAXREP];

    //char message[MAXMSG]; // pour stocker le message à envoyer au serveur

 

    // Affiche les échanges avec le serveur (false pour désactiver)

    mode_debug(true);

 

    // Connexion au serveur AppoLab

    connexion("im2ag-appolab.u-ga.fr", 9999);

    // utilisez le port 443 en cas de problème sur le 9999

    /* connexion("im2ag-appolab.u-ga.fr", 443); */

 

    // Remplacez <identifiant> et <mot de passe> ci dessous.

    envoyer_recevoir("login 12116886 \"BAHLOUL\"", reponse);

    envoyer_recevoir("load BayOfPigs", reponse);

    // Notez qu'ici on n'utilise pas la reponse du serveur

 

    //lire_clavier(message);   // message tapé au clavier

    envoyer_recevoir("help", reponse); // on envoie message, et on reçoit la réponse du serveur

    //printf("%d",reponse[2246]);

    envoyer_recevoir("depart", reponse);
    
    //char txt[MAXMSG] = "Patria o muerte\0";   
    //vider_str(result);
    //encrypter(txt, result);
    envoyer_recevoir("Par otuam eriet", reponse);
    
    decrypter(reponse, result);

    envoyer_recevoir(result, reponse);

    
    
    //envoyer_recevoir("Par otuam eriet", reponse);

    //printf("lettre = %c",result[2247]);

    //printf("%s",result);

    //printf ("Réponse du serveur: %s", reponse);c

    printf ("Réponse du serveur: %s", reponse);

    printf ("Fin de la connection au serveur\n");

    return 0;

}
