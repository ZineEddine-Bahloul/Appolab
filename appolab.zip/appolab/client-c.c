#include "client.h"
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>
#define MAXMSG MAXREP
void deplacer(char *txt,int n){
    int i=0;
    int len = strlen(txt);
    char s1[len];
    //char s2[len];    
    //printf("s1 : |%s|\n", s1);
    if (n >= 0 && n <len)
    {
        while (i<len){
            if (i<n){
                s1[i]=txt[i];
                //printf(" s[%d]=|%c| ", i, txt[i]);
            }
            else {
                txt[i - n] = txt[i];
            }
            i=i+1;
        }
        for (int j =len-n; j < len;j++){
            txt[j] = '\0';}
        strcat(txt, s1);
        for (int i = 0; i < n;i++){
            s1[i] = '\0';
        }
    }
}

void del_first_let (char *txt){
    int len = strlen(txt);
    if (len > 0)
    {
        int i = 0;
        txt[0] = '\0';
        while (i<len){
            txt[i] = txt[i + 1];
            //printf("%c",txt[i]);
            i=i+1;
        }
        // printf("\n");
    }
}
void ecrire_text(FILE *f,char *txt){
    int idx = 0;
    char car;
    car = fgetc(f);
    //printf("%c", c);
    while(car!= EOF ){
        //printf("%c\n", c);
        txt[idx] = car;
        idx++;
        car = fgetc(f);
    }
    txt[idx] = '\0';}

void encrypter(char *txt,char* message){
    char c[2]; 
    unsigned long x;
    int i = 0;
    while (txt[0] != '\0' ){
        c[0] = txt [0];
        c[1] = '\0';
        //printf("txt 1 :|%c|\n", txt[0]);
        //printf("enc:%s\n",enc);
        message [i] = txt[0];
        //printf("test:|%c|\n",c[0]);
        del_first_let(txt);
        x=c[0]%8;
        //printf("x:%d\n",x);
        if (strlen(txt) >= x && x>=1){
            //printf("txt 2 :%s\n",txt);
            deplacer(txt,x);
            //printf("\ntxt 3 :%s\n",txt);
        }
        i++;
    }
}

int main(int argc,char *argv[]) {
    FILE *f1;
    int i = argc;
    f1 = fopen(argv[1],"w");
    char reponse[MAXREP]; // pour stocker la réponse du serveur
    char message[MAXMSG]; // pour stocker le message à envoyer au serveur

    // Affiche les échanges avec le serveur (false pour désactiver)
    mode_debug(true);

    // Connexion au serveur AppoLab
    connexion("im2ag-appolab.u-ga.fr", 443);
    // utilisez le port 443 en cas de problème sur le 9999
    /* connexion("im2ag-appolab.u-ga.fr", 443); */

    // Remplacez <identifiant> et <mot de passe> ci dessous.
    envoyer_recevoir("login 12116886 BAHLOUL", reponse);
    envoyer_recevoir("load crypteMove", reponse);
    // Notez qu'ici on n'utilise pas la reponse du serveur
    // message tapé au clavier
    envoyer_recevoir("aide", reponse);    
    encrypter(reponse,message);
    strcpy(message, reponse);
    envoyer_recevoir("start", reponse);
    envoyer_recevoir(message, reponse);
    //printf ("Réponse du serveur: %s", reponse);

    printf ("Fin de la connection au serveur\n");
    return i;
}
