#include <stdio.h>


char decryptage_cesar_lettre ( char lettreLue, int cle)
{
    char lettreSuivante3;

    if (lettreLue > 'z' || lettreLue < 'A' || (lettreLue <'a' && lettreLue >'Z')){
        return lettreLue ;
    }

    else {
    
    if (lettreLue + cle > 'z' || lettreLue +cle  < 'A' || (lettreLue +cle  <'a' && lettreLue+cle >'Z')){
        lettreSuivante3 =  lettreLue + cle + 26 ;
        }
    else{
        lettreSuivante3 = lettreLue + cle ;
        }
    }
    return lettreSuivante3 ;
}
void decryptage_cesar(char *enc,char *txt){
    int cle = 'C' - enc[0] ;
    //printf("%d\n", cle);
    int len = strlen(enc);
    for (int idx = 0; idx < len; idx++){
        txt[idx] = decryptage_cesar_lettre(enc[idx],cle);
        //printf("c:%c\n", txt[idx]);
        txt[idx + 1] = '\0';
    }
}

int main (int argc, char *argv[]){
    char txt[100] = "Nspcp Lwtnp,";
    char enc[100];
    decryptage_cesar(txt, enc);
    printf("%s", enc);
    /*FILE *f1;
    FILE *f2;
    if (argc == 3){
        char c,x;
        f1 = fopen(argv[1],"r");
        f2 = fopen(argv[2],"w");
        c = fgetc(f1); 
        while(c!= EOF){
            c = decryptage_cesar_lettre(c);
            fprintf(f2,"%c",c);
            c = fgetc(f1);
        }
    }*/
    return 0;
}