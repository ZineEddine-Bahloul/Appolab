#include "client.h"
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>

#define MAXMSG MAXREP

char decryptage_cesar_lettre ( char lettreLue, int cle)
{
    char lettreSuivante3;

    if (lettreLue > 'z' || lettreLue < 'A' || (lettreLue <'a' && lettreLue >'Z')){
        return lettreLue ;
    }

    else {
        if ((lettreLue + cle < 'a' && (lettreLue >='a' && lettreLue<='z')) || (lettreLue + cle < 'A' && (lettreLue >='A' && lettreLue<='Z')))
        {          
            lettreSuivante3 =  lettreLue + cle + 26 ;
        }
        else if ((lettreLue + cle > 'z' && (lettreLue >='a' && lettreLue<='z')) || (lettreLue + cle > 'Z' && (lettreLue >='A' && lettreLue<='Z')))
        {
            lettreSuivante3 =  lettreLue + cle -26  ;
        }       
        else{
            lettreSuivante3 = lettreLue + cle ;
            }
    }
    return lettreSuivante3 ;
}
void decryptage_cesar(char *enc,char *txt,char c){
    int cle = 'C' - c ;
    //cle = cle * -1;
    int len = strlen(enc);
    for (int idx = 0; idx < len; idx++){
        txt[idx] = decryptage_cesar_lettre(enc[idx],cle);
        txt[idx + 1] = '\0';
    }
}

int main() {
    char reponse[MAXREP]; // pour stocker la réponse du serveur
    char message[MAXMSG]; // pour stocker le message à envoyer au serveur

    // Affiche les échanges avec le serveur (false pour désactiver)
    mode_debug(true);

    // Connexion au serveur AppoLab
    connexion("im2ag-appolab.u-ga.fr", 9999);
    // utilisez le port 443 en cas de problème sur le 9999
    /* connexion("im2ag-appolab.u-ga.fr", 443); */

    // Remplacez <identifiant> et <mot de passe> ci dessous.
    envoyer_recevoir("login 12116886 BAHLOUL", reponse);
    envoyer_recevoir("load planB", reponse);

    envoyer_recevoir("ok", reponse); // on envoie message, et on reçoit la réponse du serveur

    envoyer_recevoir("depart", reponse);
    envoyer_recevoir("42",reponse);
    envoyer_recevoir("help",reponse);
    //
    //printf ("Réponse du serveur: %s", message);
    int cle = reponse[0];
    decryptage_cesar("hasta la revolucion", message,cle);
    envoyer_recevoir(message, reponse);
    decryptage_cesar(reponse, message,cle);
    envoyer_recevoir(message, reponse);

    printf ("Réponse du serveur: %s", reponse);
    printf ("Fin de la connection au serveur\n");
}
