#include "client.h"

#include <stdio.h>

#include <ctype.h>

#include <stdbool.h>

#include <string.h>


#define MAXMSG MAXREP
void vider_str(char *str){
    int len1 = strlen(str);
    for (int i = 0; i < len1; i++)
    {
        str[i] = '\0';
    }
}
void inserer_premier_char (char *txt,char c){
    int len3 = strlen(txt);
    char txt_inter2[MAXREP];
    vider_str(txt_inter2);
    for (int idx2 = 0; idx2 < len3 + 1; idx2++)
    {
        if (idx2 == 0){
            txt_inter2[idx2] = c;
        }
        else {
            txt_inter2[idx2] = txt[idx2-1] ;
            txt_inter2[idx2 + 1] = '\0';
        }
    }
    vider_str(txt);
    strcpy(txt,txt_inter2);
    vider_str(txt_inter2);
}

void decaler_xderniers(char *txt, int x){
    char c2;
    int len2 = strlen(txt);
    char txt_inter[MAXREP];
    vider_str(txt_inter);
    int dernier_idx = len2 - 1;
    if (x <= len2 && x>=1)
    {
        for (int idx1 = 0; idx1 < x; idx1++){
            c2 = txt[dernier_idx - idx1 ];
            txt[dernier_idx - idx1] = '\0';
            inserer_premier_char(txt_inter, c2);
        }
        strcat(txt_inter, txt);
        vider_str(txt);
        strcpy(txt,txt_inter);
        vider_str(txt_inter);
    }
}
void decrypter(char *enc,char *txt){
    char c;
    int x;
    vider_str(txt);
    while (enc[0] != '\0')
    {
        int len4 = strlen(enc);
        c = enc[len4 - 1];
        x = c % 8;
        decaler_xderniers(txt, x);
        inserer_premier_char(txt, c);
        enc[len4 - 1] = '\0';
    }
}

int in(char *str,char c,int *n){
    int len_str = strlen(str);
    int ret = 1;
    *n = -1;
    for (int idx_str = 0; idx_str < len_str;idx_str++){
        if (str[idx_str]==c){
            ret = 0;
            *n = idx_str;
            break;
        }
    }
    return ret; 
}

void deplacer_c_fin(char *txt,int idx){
    char str1[100];
    char str2[100];
    vider_str(str1);
    vider_str(str2);
    int len = strlen(txt);
    char c[2];
    c[0] = txt[idx];
    c[1] = '\0';
    int j = 0;
    for (int i = 0; i < len;i++)
    {
        if (i <= idx-1){
            str1[i] = txt[i];         
            str1[i + 1] = '\0';
        }
        else if (i>=idx+1)
        {
            str2[j] = txt[i];
            str2[j+1] = '\0';
            j++;
        }
    }
    vider_str(txt);
    strcat(str1, str2);
    vider_str(str2);
    strcat(str1, c);
    strcpy(txt, str1);
    vider_str(str1);
    vider_str(c);
}

void crypte_seq(char *enc, char *txt)
{
    char seq[100];
    vider_str(seq);
    vider_str(txt);
    char c[2];
    int Bool;
    int idx_c;
    c[1] = '\0';
    char d;
    int len = strlen(enc);
    for (int idx = 0; idx < len; idx++){
        c[0] = enc[idx];
        Bool = in(seq, c[0],&idx_c);
        if (Bool==1){
            strcat(seq, c);
            d = c[0];
        }
        else if (Bool==0)
        {
            if (seq[0]==c[0]){
                d = seq[strlen(seq)-1];
            }
            else {
                d = seq[idx_c - 1];
            }
        }
        deplacer_c_fin(seq, idx_c);
        txt[idx] = d;
        txt[idx + 1] = '\0';
    }
    
}

void decrypte_seq(char *enc, char *txt)
{
    char seq[MAXMSG];
    vider_str(seq);
    vider_str(txt);
    char c[2];
    int Bool;
    int idx_c;
    c[1] = '\0';
    char d;
    int len = strlen(enc);
    for (int idx = 0; idx < len; idx++){
        c[0] = enc[idx];
        Bool = in(seq, c[0],&idx_c);
        if (Bool==1){
            strcat(seq, c);
            d = c[0];
        }
        else if (Bool==0)
        {
            if (seq[strlen(seq)-1]==c[0]){
                d = seq[0];
                idx_c = 0;
            }
            else {
                d = seq[idx_c + 1];
                idx_c++;
            }
        }
        deplacer_c_fin(seq, idx_c);
        txt[idx] = d;
        txt[idx + 1] = '\0';
    }
    
}


int main() {

    char reponse[MAXREP]; // pour stocker la réponse du serveur

    char result[MAXREP];

    mode_debug(true);

    connexion("im2ag-appolab.u-ga.fr", 9999);

    envoyer_recevoir("login 12116886 \"BAHLOUL\"", reponse);

    envoyer_recevoir("load crypteSeq", reponse);

    decrypter(reponse, result);

    envoyer_recevoir(result, reponse);

    envoyer_recevoir("depart", reponse);
    
    decrypter(reponse, result);

    char result2[MAXMSG];

    crypte_seq(result, result2);
    
    envoyer_recevoir(result2, reponse);

    vider_str(result);
    vider_str(result2);
    int j = 0;
    for (unsigned long i = 83; i < strlen(reponse); i ++)
    {
        result[j] = reponse[i];
        j++;
        result[j] = '\0';
    }

    decrypte_seq(result, result2);
    envoyer_recevoir(result2, reponse);

    printf ("Fin de la connection au serveur\n");

    return 0;

}
