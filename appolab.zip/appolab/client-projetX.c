#include "client.h"
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>

#define MAXMSG MAXREP

int main() {
    char reponse[MAXREP]; // pour stocker la réponse du serveur
    //char message[MAXMSG]; // pour stocker le message à envoyer au serveur

    // Affiche les échanges avec le serveur (false pour désactiver)
    mode_debug(true);

    // Connexion au serveur AppoLab
    connexion("im2ag-appolab.u-ga.fr", 9999);
    // utilisez le port 443 en cas de problème sur le 9999
    /* connexion("im2ag-appolab.u-ga.fr", 443); */

    // Remplacez <identifiant> et <mot de passe> ci dessous.
    envoyer_recevoir("login 12116886 BAHLOUL", reponse);
    envoyer_recevoir("load projetX", reponse);

    envoyer_recevoir("help", reponse); // on envoie message, et on reçoit la réponse du serveur

    envoyer_recevoir("depart", reponse);
    envoyer_recevoir("veni vidi vici",reponse);
    printf ("Fin de la connection au serveur\n");
}
