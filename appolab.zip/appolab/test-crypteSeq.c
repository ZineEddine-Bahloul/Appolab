#include "client.h"

#include <stdio.h>

#include <ctype.h>

#include <stdbool.h>

#include <string.h>

void vider_str(char *str){
    for (unsigned long i = 0; i < strlen(str); i++){
        str[i] = '\0';
    }
}
int in(char *str,char c,int *n){
    int len_str = strlen(str);
    int ret = 1;
    *n = -1;
    for (int idx_str = 0; idx_str < len_str;idx_str++){
        if (str[idx_str]==c){
            ret = 0;
            *n = idx_str;
            break;
        }
    }
    return ret; 
}

void deplacer_c_fin(char *txt,int idx){
    char str1[100];
    char str2[100];
    vider_str(str1);
    vider_str(str2);
    int len = strlen(txt);
    char c[2];
    c[0] = txt[idx];
    c[1] = '\0';
    int j = 0;
    for (int i = 0; i < len;i++)
    {
        if (i <= idx-1){
            str1[i] = txt[i];         
            str1[i + 1] = '\0';
        }
        else if (i>=idx+1)
        {
            str2[j] = txt[i];
            str2[j+1] = '\0';
            j++;
        }
    }
    vider_str(txt);
    strcat(str1, str2);
    vider_str(str2);
    strcat(str1, c);
    strcpy(txt, str1);
    vider_str(str1);
    vider_str(c);
}

void crypte_seq(char *enc, char *txt)
{
    char seq[100];
    vider_str(seq);
    vider_str(txt);
    char c[2];
    int Bool;
    int idx_c;
    c[1] = '\0';
    char d;
    int len = strlen(enc);
    for (int idx = 0; idx < len; idx++){
        c[0] = enc[idx];
        Bool = in(seq, c[0],&idx_c);
        if (Bool==1){
            strcat(seq, c);
            d = c[0];
        }
        else if (Bool==0)
        {
            if (seq[0]==c[0]){
                d = seq[strlen(seq)-1];
            }
            else {
                d = seq[idx_c - 1];
            }
        }
        deplacer_c_fin(seq, idx_c);
        txt[idx] = d;
        txt[idx + 1] = '\0';
    }
    
}

void decrypte_seq(char *enc, char *txt)
{
    char seq[1000];
    vider_str(seq);
    vider_str(txt);
    char c[2];
    int Bool;
    int idx_c;
    c[1] = '\0';
    char d;
    int len = strlen(enc);
    for (int idx = 0; idx < len; idx++){
        c[0] = enc[idx];
        Bool = in(seq, c[0],&idx_c);
        if (Bool==1){
            strcat(seq, c);
            d = c[0];
        }
        else if (Bool==0)
        {
            if (seq[strlen(seq)-1]==c[0]){
                d = seq[0];
            }
            else {
                d = seq[idx_c + 1];
            }
        }
        deplacer_c_fin(seq, idx_c);
        txt[idx] = d;
        txt[idx + 1] = '\0';
    }
    
}

int main(){
    char txt[100] = "abcaabc";
    char enc[100] = "";
    decrypte_seq(txt, enc);
    printf("%s", enc);
}