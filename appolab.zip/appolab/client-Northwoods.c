#include "client.h"

#include <stdio.h>

#include <ctype.h>

#include <stdbool.h>

#include <string.h>

#define MAXMSG MAXREP


void vider_str(char *str){
    int len1 = strlen(str);
    for (int i = 0; i < len1; i++)
    {
        str[i] = '\0';
    }
}

int in(char *str,char c,int *n){
    int len_str = strlen(str);
    int ret = 1;
    *n = -1;
    for (int idx_str = 0; idx_str < len_str;idx_str++){
        if (str[idx_str]==c){
            ret = 0;
            *n = idx_str;
            break;
        }
    }
    return ret; 
}

void deplacer_c_fin(char *txt,int idx){
    char str1[100];
    char str2[100];
    vider_str(str1);
    vider_str(str2);
    int len = strlen(txt);
    char c[2];
    c[0] = txt[idx];
    c[1] = '\0';
    int j = 0;
    for (int i = 0; i < len;i++)
    {
        if (i <= idx-1){
            str1[i] = txt[i];         
            str1[i + 1] = '\0';
        }
        else if (i>=idx+1)
        {
            str2[j] = txt[i];
            str2[j+1] = '\0';
            j++;
        }
    }
    vider_str(txt);
    strcat(str1, str2);
    vider_str(str2);
    strcat(str1, c);
    strcpy(txt, str1);
    vider_str(str1);
    vider_str(c);
}
void decrypte_seq(char *enc, char *txt)
{
    char seq[MAXMSG];
    vider_str(seq);
    vider_str(txt);
    char c[2];
    int Bool;
    int idx_c;
    c[1] = '\0';
    char d;
    int len = strlen(enc);
    for (int idx = 0; idx < len; idx++){
        c[0] = enc[idx];
        Bool = in(seq, c[0],&idx_c);
        if (Bool==1){
            strcat(seq, c);
            d = c[0];
        }
        else if (Bool==0)
        {
            if (seq[strlen(seq)-1]==c[0]){
                d = seq[0];
                idx_c = 0;
            }
            else {
                d = seq[idx_c + 1];
                idx_c++;
            }
        }
        deplacer_c_fin(seq, idx_c);
        txt[idx] = d;
        txt[idx + 1] = '\0';
    }
    
}

void recup_mdp(char *enc, char *mdp){
    int len = strlen(enc);
    vider_str(mdp);
    int j = 0;
    for (int idx = 29; idx >= 10;idx --){
        mdp[j] = enc[len - idx];
        mdp[j+1] = '\0';
        j++;
    }
}


int main() {

    char reponse[MAXREP]; // pour stocker la réponse du serveur

    char result[MAXREP];

    mode_debug(true);

    connexion("im2ag-appolab.u-ga.fr",443);

    envoyer_recevoir("login 12116886 \"BAHLOUL\"", reponse);

    envoyer_recevoir("load Northwoods", reponse);

    envoyer_recevoir("depart", reponse);

    envoyer_recevoir("hasta la victoria siempre", reponse);
    vider_str(result);
    decrypte_seq(reponse, result);
    printf("%s", result);
    char result2[100];
    recup_mdp(result, result2);
    envoyer_recevoir(result2, reponse);
    vider_str(result);
    envoyer_recevoir("Therh wiliebrlnoeNwebtntioENgTNy-FbuT", reponse);
    vider_str(result);
    vider_str(result2);
    int j = 0;
    for (unsigned long i = 24; i < strlen(reponse); i ++)
    {
        result[j] = reponse[i];
        j++;
        result[j] = '\0';
    }
    decrypte_seq(result, result2);
    envoyer_recevoir(result2, reponse);


    printf ("Réponse du serveur: %s", reponse);

    printf ("Fin de la connection au serveur\n");

    return 0;

}
