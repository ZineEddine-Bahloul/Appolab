#include "client.h"
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>

#define MAXMSG MAXREP

int main() {
    char reponse[MAXREP]; // pour stocker la réponse du serveur
    // char message[MAXMSG]; // pour stocker le message à envoyer au serveur

    // Affiche les échanges avec le serveur (false pour désactiver)
    mode_debug(true);

    // Connexion au serveur AppoLab
    connexion("im2ag-appolab.u-ga.fr", 443);
    // utilisez le port 443 en cas de problème sur le 9999
    /* connexion("im2ag-appolab.u-ga.fr", 443); */

    // Remplacez <identifiant> et <mot de passe> ci dessous.
    envoyer_recevoir("login 12116886 BAHLOUL", reponse);
    envoyer_recevoir("load TUTORIEL", reponse);
    // Notez qu'ici on n'utilise pas la reponse du serveur
  // message tapé au clavier
    envoyer_recevoir("depart", reponse);
    envoyer_recevoir("OK", reponse);
    char momo[MAXMSG]="OUI";

    while (envoyer_recevoir(momo,reponse) != 0){
        int c = strlen(reponse);
        int n = strlen(momo);
        for (int i = 0; i < n; i++)
        {
            momo[i]='\0';
        }
        
        
        for (int i=0;i<c;i++){
            if ( (reponse[i]>='a' && reponse[i] <= 'z'))
            {
              momo[i]=reponse[i]-32;    
            }
            else {
                momo[i]=reponse[i];  
            }
        } 

    }

    printf ("Réponse du serveur: %s", reponse);

    printf ("Fin de la connection au serveur\n");
    return 0;
}
